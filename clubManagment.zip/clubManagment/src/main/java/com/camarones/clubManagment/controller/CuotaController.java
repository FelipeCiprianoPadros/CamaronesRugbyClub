package com.camarones.clubManagment.controller;

import com.camarones.clubManagment.model.Cuota;
import com.camarones.clubManagment.service.CuotaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cuota")
public class CuotaController {

    @Autowired
    private CuotaService cs;

    @PostMapping("")
    public ResponseEntity SaveCuota(@RequestBody Cuota cuota){
        return cs.SaveCuota(cuota);
    }

    @PostMapping("/{id}/update")
    public ResponseEntity UpdateCuota(@PathVariable int id,@RequestBody Cuota cuota){
        return cs.UpdateCuota(id,cuota);
    }

    @PostMapping("/{id}/delete")
    public ResponseEntity DeleteCuota(@PathVariable int id){
        return cs.DeleteCuota(id);
    }

}
