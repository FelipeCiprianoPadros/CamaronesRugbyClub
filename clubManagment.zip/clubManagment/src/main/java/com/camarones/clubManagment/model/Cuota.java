package com.camarones.clubManagment.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Cuota {

    @Id
    private Integer id;

    private String mesCuota;

    private LocalDate fechaVencimiento;

    private LocalDate fechaPago;

    private double precioCuota;

    @ManyToMany(mappedBy = "cuota")
    private List<Socio> socios;
}
