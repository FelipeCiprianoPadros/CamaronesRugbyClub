package com.camarones.clubManagment.service;

import com.camarones.clubManagment.model.Operador;
import com.camarones.clubManagment.repository.OperadorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@Service
public class OperadorService {

    @Autowired
    private OperadorRepository or;

    public OperadorService(OperadorRepository or){
        this.or = or;
    }

    public ResponseEntity SaveOperador (Operador operador){
        try{
            return ResponseEntity.status(CREATED).build();
        }catch (Exception e){
            return ResponseEntity.status(INTERNAL_SERVER_ERROR).build();
        }
    }

    public ResponseEntity UpdateOperador (int id, Operador operador){
        try{
            return ResponseEntity.status(CREATED).build();
        }catch (Exception e){
            return ResponseEntity.status(INTERNAL_SERVER_ERROR).build();
        }
    }

    public ResponseEntity DeleteOperador (int id){
        try{
            return ResponseEntity.status(CREATED).build();
        }catch (Exception e){
            return ResponseEntity.status(INTERNAL_SERVER_ERROR).build();
        }
    }


}
