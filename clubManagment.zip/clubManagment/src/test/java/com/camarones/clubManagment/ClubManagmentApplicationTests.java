package com.camarones.clubManagment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClubManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
